<template>
    <div>
      <create-task></create-task>
      <router-link to="/">Вернуться к списку задач</router-link> <!-- Ссылка для возврата на главную страницу -->
    </div>
  </template>
  
  <script>
  import CreateTask from '@/components/CreateTask.vue';
  
  export default {
    components: {
      CreateTask
    }
  };
  </script>
<style>

router-link {
  margin: 10px;
  padding: 10px 15px;
  background-color: #007BFF;
  color: white;
  text-decoration: none;
  border-radius: 5px;
}
router-link:hover {
  background-color: #0056b3;
}
</style>  