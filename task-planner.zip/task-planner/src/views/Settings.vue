<template>
    <div>
        <h1>Настройки</h1>
        <p>Здесь могут быть настройки приложения</p>
    </div>
</template>

<script>
export default {};
</script>