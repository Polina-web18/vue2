// модуль для управления задачами
const state = {
    tasks: ['gerfoihjgu','dfghj'], 
    loading: false
};

const mutations = {
    ADD_TASK(state, task) {
        state.tasks.push(task);
    },
    REMOVE_TASK(state, taskId) {
        state.tasks = state.tasks.filter(task => task.id !== taskId);
    },
    SET_LOADING(state, loading) {
        state.loading = loading;
    },
    UPDATE_TASK(state, updatedTask) {
        const index = state.tasks.findIndex(task => task.id === updatedTask.id);
        if (index !== -1) {
            Vue.set(state.tasks, index, updatedTask);
        }
    }
};

const actions = {
    async addTask({ commit }, task) {
        commit('SET_LOADING', true);
        // cимуляция API вызова
        await new Promise(resolve => setTimeout(resolve, 1000));
        commit('ADD_TASK', { id: Date.now(), ...task });
        commit('SET_LOADING', false);
    },
    async removeTask({ commit }, taskId) {
        commit('SET_LOADING', true);
        // cимуляция API вызова
        await new Promise(resolve => setTimeout(resolve, 1000));
        commit('REMOVE_TASK', taskId);
        commit('SET_LOADING', false);
    },
    async updateTask({ commit }, updatedTask) {
        commit('SET_LOADING', true);
        // cимуляция API вызова
        await new Promise(resolve => setTimeout(resolve, 1000));
        commit('UPDATE_TASK', updatedTask);
        commit('SET_LOADING', false);
    }
};

const getters = {
    allTasks: state => state.tasks,
    loading: state => state.loading
};

export default {
    namespaced: true,
    state,
    mutations,
    actions,
    getters
};