<template>
    <div class="task-card">
        <h3>{{ task.title }}</h3>
        <p>Описание: {{ task.description }}</p>
        <p>Приоритет: {{ task.priority }}</p>
        <button @click="$emit('remove')">Удалить</button>
    </div>
</template>

<script>
export default {
    props: {
        task: Object
    }
};
</script>

<style scoped>
.task-card {
    border: 1px solid #ccc;
    padding: 10px;
    margin: 10px 0;
}
</style>