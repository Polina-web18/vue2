<template>
    <div>
      <h1>Задачи</h1>
      <div>
        <router-link to="/">Список задач</router-link> <!-- Ссылка на TaskList -->
        <router-link to="/create">Создать задачу</router-link> <!-- Ссылка на CreateTask -->
      </div>
      <tasks-list v-if="$route.path === '/'"></tasks-list> 
    </div>
  </template>
  
  <script>
  import TasksList from '@/components/TasksList.vue';
  
  export default {
    components: {
      TasksList
    }
  };
  </script>
  <style>

router-link {
  margin: 10px;
  padding: 10px 15px;
  background-color: #007BFF;
  color: white;
  text-decoration: none;
  border-radius: 5px;
}
router-link:hover {
  background-color: #0056b3;
}
</style>
  