<template>
    <form @submit.prevent="createTask">
        <h1>Создать задачу</h1>
        <input v-model="task.title" placeholder="Заголовок" required />
        <textarea v-model="task.description" placeholder="Описание" required></textarea>
        <select v-model="task.priority">
            <option value="low">Низкий</option>
            <option value="medium">Средний</option>
            <option value="high">Высокий</option>
        </select>
        <button type="submit">Добавить задачу</button>
        <div v-if="loading">Загрузка...</div>
    </form>
</template>

<script>
import { mapGetters } from 'vuex';
import { mapActions } from 'vuex';

export default {
    data() {
        return {
            task: {
                title: '',
                description: '',
                priority: 'medium'
            }
        };
    },
    computed: {
        ...mapGetters('tasks', ['loading'])
    },
    methods: {
        ...mapActions('tasks', ['addTask']),
        async createTask() {
            await this.addTask(this.task);
            this.task.title = '';
            this.task.description = '';
            this.task.priority = 'medium';
        }
    }
};
</script>