<template>
    <div>
        <h1>Мои задачи</h1>
        <task-card 
            v-for="task in tasks" 
            :key="task.id" 
            :task="task"
            @remove="removeTask(task.id)">
        </task-card>
        <div v-if="loading">Загрузка...</div>
    </div>
</template>

<script>
import { mapGetters } from 'vuex';
import { mapActions } from 'vuex';
import TaskCard from './TaskCard.vue';

export default {
    components: {
        TaskCard
    },
    computed: {
        ...mapGetters('tasks', ['allTasks', 'loading']),
        tasks() {
            return this.allTasks;
        }
    },
    methods: {
        ...mapActions('tasks', ['removeTask'])
    }
};
</script>